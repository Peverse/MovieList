package com.example.movielist;

public class Movie{
    public String Title;
    public String Genre;
    public String Year;
}
